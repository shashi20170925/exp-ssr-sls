﻿import { createStore, applyMiddleware, compose } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/es/storage';
import reducer from './reducers';
import { logger, thunk } from './middleware';
import { composeWithDevTools } from "redux-devtools-extension";
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { HashRouter ,Switch,Route,Redirect } from 'react-router-dom';
import { PersistGate, autoRehydrate } from 'redux-persist/es/integration/react';
import { AppRoutes } from './app-routing/app-routes';

import { BaseApp } from './containers/BaseApp';
import * as str from './store/store';
import { Environment } from './utilities/environment';



//<<<<<<
const init = (opts) => {

    const env = new Environment(opts);
    let divId = env.componentId;

    const middleware = [thunk, logger]
    const composeEnhancers = compose;

    const configureStore = composeEnhancers(
        applyMiddleware(...middleware),

     
    )(createStore)

    let config = {
        key: 'root',
        storage,
    }

    const combinedReducer = persistReducer(config, reducer)

    let store = configureStore(combinedReducer, autoRehydrate)
    let persistor = persistStore(store)

    //>>>>>>>>
    //store.dispatch(bundleOverviewActions.resetRootState());


     ReactDOM.render(
            <Provider store={store}>
                <PersistGate persistor={persistor}>
                    <BaseApp />
                </PersistGate>
            </Provider>,
            document.querySelector(`[data-gss-componentid="${divId}"]`)
        );    
}

declare const window: any;
window.acmAdminTool = window.acmAdminTool || {};
window.acmAdminTool.init = init;
