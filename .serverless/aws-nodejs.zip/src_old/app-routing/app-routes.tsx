﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { HashRouter, Redirect, Route, Switch } from 'react-router-dom';

import { App } from './../containers/App';

export class AppRoutes extends React.Component<any, any> {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <HashRouter >
                <Switch>
                    <Route exact={true} path="/" component={App} />
                </Switch>
            </HashRouter>
        );
    }

}
