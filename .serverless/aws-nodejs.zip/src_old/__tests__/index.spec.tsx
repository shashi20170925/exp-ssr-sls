// import * as React from 'react';
// import { shallow } from "enzyme";
// import toJson from 'enzyme-to-json';
// //import * as TestUtils from 'react-dom/test-utils';
// import Hello from "../../src/components/Hello";


// test('Testing Hello',()=>{
//     const componet=shallow(<Hello />);
//     const tree=toJson(componet);

//     expect(componet.contains('Hello!')).toBe(true);
// });
// it("renders the heading" , () => {
//     const result = shallow(<Hello />).contains(<h1>Hello!</h1>);
//     expect(result).toBeTruthy();
// });