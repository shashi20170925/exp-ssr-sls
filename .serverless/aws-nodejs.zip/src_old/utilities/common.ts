import * as constants from '../constants/app-constants';
import { Environment } from './environment';

declare const window: any;

export namespace GuidGenerator {

    const s4 = () => {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

    export const NewGuid = () => {
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }
}


export const AccessCodeAvailableKeys = [
    {
        id: 1,
        LKMTitle: "TOP5_CODE_TYPE",
        CodeDisplayText: "Top 5",
    },
    {
        id: 2,
        LKMTitle: "ALL34_CODE_TYPE",
        CodeDisplayText: "All 34"
    },
    {
        id: 3,
        LKMTitle: "UPGRADE34_CODE_TYPE",
        CodeDisplayText: "Upgrade 34"
    }
];

export const AccessCodeTypes = [
    {
        id: 1,
        LKMTitle: "TOP5_TITLE",
        CodeDisplayText: "Top 5",
    },
    {
        id: 2,
        LKMTitle: "ALL34_TITLE",
        CodeDisplayText: "All 34"
    },
    {
        id: 3,
        LKMTitle: "UPGRADE34_TITLE",
        CodeDisplayText: "Upgrade 34"
    }
]

export const WorkFlowTypes = [
    {
        Id: 1,
        LKMTitleGrid: "DISTRIBUTION_METHOD_SINGLE",
        WorkflowDisplayTextGrid: "Unique",
        LKMTitleCreate: "CREATE_BUNDLE_DISTRIBUTION_METHOD_SINGLE_SHORT",
        WorkflowDisplayTextCreate: "A unique, <strong>single-use</strong> access code for each individual."
    },
    {
        Id: 2,
        LKMTitleGrid: "DISTRIBUTION_METHOD_MULTI",
        WorkflowDisplayTextGrid: "MULTI-USE",
        LKMTitleCreate: "CREATE_BUNDLE_DISTRIBUTION_METHOD_MULTI_SHORT",
        WorkflowDisplayTextCreate: "One <strong>multi-use</strong> access code for all individuals to share."


    },
    
];



export const stringFormater = function (text: string, replaceValues: string[]) {
    var theString = text;
    for (var i = 0; i < replaceValues.length; i++) {
        var regEx = new RegExp("\\{" + (i ) + "\\}", "gm");
        theString = theString.replace(regEx, replaceValues[i]);
    }
    return theString;
}

 export const getLanguage = (): string => {
    var obj = document.querySelector("html");
    var attr = obj.attributes["lang"];
    if (!!attr) {
        return attr.value;
    }
    return null;
}


export const getCodeTypeItemById = (id:number)=>{

    return AccessCodeTypes.filter((item) => {
        if (item.id == id) {
            return item;
        }
         
    })[0];
 }
export const GetAvailableAccessCodeByID = (id: number) => {

    return AccessCodeAvailableKeys.filter((item) => {
        if (item.id == id) {
            return item;
        }

    })[0];
}

export const getWorkflowTypeById = (id: number) => {

    return WorkFlowTypes.filter((item) => {
        if (item.Id == id) {
            return item;
        }

    })[0];
}

export const normalizeRequest = (params) => {
    const env = new Environment({});
    params.gssComponentId = env.componentId;

    if (window.GSS && window.GSS.common) {
        params.gssClientId = window.GSS.common.getAttributeValue(window.GSS.widget.attributeNames.clientId, null);
        params = window.GSS.common.addAntiForgeryToken(params);
    }

    return params;
}





