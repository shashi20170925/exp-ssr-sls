let environment = null;


export class Environment<IEnvironment> {
  componentId;
  endpoint;
  env;
  pageSizes;
  defaultPageSize;
  gallupAssociateRole;
  readBucketsRole;
  manageBucketCodesRole

  constructor(obj) {
    if (!environment) {
      environment = this;
    }

    if (obj) {
        this.componentId = obj.componentId;
        this.endpoint = process.env.NODE_ENV == 'production' ?
            '/' : obj.endpoint;
        this.pageSizes = obj.pageSizes || '3,5,10,25,50';
        this.defaultPageSize = obj.defaultPageSize || '5';
        this.gallupAssociateRole = obj.gallupAssociateRole ||'gallup_associate';
        this.readBucketsRole = obj.readBucketsRole ||'read_all_code_buckets';
        this.manageBucketCodesRole = obj.manageBucketCodesRole ||'manage_bucket_codes';
        this.env = obj.env;
    }


    return environment;
  }

}
