import * as React from 'react';
import { bindActionCreators } from 'redux';

import { connect } from 'react-redux';
import { RouteComponentProps } from 'react-router';
import { RootState } from '../../reducers';

import {AppRoutes } from '../../app-routing/app-routes';
export namespace BaseApp {
    export interface Props {
 
    

    }

    export interface State {
        /* empty */
    }
}

export class BaseApp extends React.Component<any, any> {



    render() {
            return (<div>
               <AppRoutes />
              </div>);
    }


}


