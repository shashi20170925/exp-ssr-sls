﻿


//use these templates for navigation
export const BUNDLE_DETAILS_AVAILABLE_TEMPLATE_R0 = "/bundleDetails/{0}/available";

export const BUNDLE_DETAILS_AVAILABLE_TEMPLATE = "/bundleDetails/{0}/available";

export const DISTRIBUTE_CODES_TEMPLATE_R0 = "/distributeCodes/{0}";
export const EMAIL_DISTRIBUTE_CODES_TEMPLATE_R0 = `/distributeCodes/{0}/email`;
export const FILE_DISTRIBUTE_CODES_TEMPLATE_R0 = `/distributeCodes/{0}/file`;

export const DEACTIVATE_CODES_TEMPLATE_R0 = "/deactivate/{0}";
export const REACTIVATE_CODES_TEMPLATE_R0 = "/reactivate/{0}";
export const TRANSFER_CODES_TEMPLATE_R0 = "/transferCodes/{0}";



export const DASHBOARD_TEMPLATE = "/dashboard/1";
export const DASHBOARD_FIRST_CODE_TYPE_PATH = "/dashboard/1";

export const CREATE_BUNDLE_STEP_CODE_SELECTION = "/createBundle/step1";
export const CREATE_BUNDLE_STEP2_BUNDLE = "/createBundle/step2";

export const CREATE_BUNDLE_STEP_WORKFLOW_SELECTION = "/createBundle/workflowSelection";

export const CREATE_BUNDLE_STEP3_CODES = "/createBundle/step3";
export const CREATE_BUNDLE_STEP4_OWNER = "/createBundle/step4";
export const CREATE_BUNDLE_CONFIRMATION = "/createBundle/confirmation";


export const ADD_CODES_STEP1_CODE_TYPE = "/addCodes/step1";
export const ADD_CODES_STEP2_ADD_SEATS = "/addCodes/step2";


///to = {`/distributeCodes/${this.props.bundleDetailsProps.Bundle.ID}`}



