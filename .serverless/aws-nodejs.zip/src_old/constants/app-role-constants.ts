﻿  export const GALLUP_ASSOCIATE = 'gallup_associate';
  export const READ_BUCKETS = 'read_all_code_buckets';
  export const MANAGE_BUCKET_CODES = 'manage_bucket_codes';
