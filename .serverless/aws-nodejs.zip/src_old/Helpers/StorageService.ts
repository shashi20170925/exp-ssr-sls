﻿export class StorageService {

    static setItem = (name: string, value: any) => {
        window.sessionStorage.setItem(name, JSON.stringify(value));
    }
    static getItem = <T>(name: string) => {
        const value = window.sessionStorage.getItem(name);
        if (!!value) {
            return JSON.parse(value) as T;
        }
        return null;
    }

    static clearCache = () => {
        window.sessionStorage.clear();
    }

    
}