﻿import { createStore, applyMiddleware, compose } from 'redux';
import { persistStore, persistReducer  } from 'redux-persist';
import storage from 'redux-persist/es/storage';
import reducer from '../reducers';
import { logger, thunk } from '../middleware';

import { composeWithDevTools } from "redux-devtools-extension";

export namespace createAppStore1 {
    const middleware = [thunk, logger]
    const composeEnhancers = compose;

    const configureStore = composeEnhancers(
        applyMiddleware(...middleware),
    )(createStore)

    let config = {
        key: 'root',
        storage,
    }

    const combinedReducer = persistReducer(config, reducer)

   export const createAppStore = () => {
        let store = configureStore(combinedReducer)

        return { store }
    }

    export const getPersister = (store) => {
        let persistor = persistStore(store);

 };

}
//export const createAppStore = ()=>{
//    const middleware = [thunk, logger]
//    const composeEnhancers = compose;

//    const configureStore = composeEnhancers(
//        applyMiddleware(...middleware),
//    )(createStore)

//    let config = {
//        key: 'root',
//        storage,
//    }

//    const combinedReducer = persistReducer(config, reducer)

//    const createAppStore = () => {
//        let store = configureStore(combinedReducer)
//        let persistor = persistStore(store)

//        return { persistor, store }
//    }
//}





