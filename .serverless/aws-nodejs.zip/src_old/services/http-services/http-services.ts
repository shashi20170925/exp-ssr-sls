﻿import axios from 'axios';
import { AxiosPromise, AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import { normalizeRequest } from './../../utilities/common';
//import * as Promise from 'bluebird';
import { Environment } from './../../utilities/environment';




export namespace HttpService {

    function baseUrl() {
        const settings = new Environment({});
        const END_POINT = settings.endpoint;

        // const END_POINT = 'http://gss.accesscodemanagement/';
        //const END_POINT = 'http://localhost:11111/';


        return END_POINT;
    }
    const config = {

        headers: process.env.NODE_ENV === 'development'
            ? {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im15OWxsd3U5Q3o1MzZ1TnFWYmt6N3o1QXdfYyIsImtpZCI6Im15OWxsd3U5Q3o1MzZ1TnFWYmt6N3o1QXdfYyJ9.eyJpc3MiOiJodHRwczovL2xvZ2luZC5nYWxsdXAuY29tIiwiYXVkIjoiaHR0cHM6Ly9sb2dpbmQuZ2FsbHVwLmNvbS9yZXNvdXJjZXMiLCJleHAiOjE1MjYwNjIxNzEsIm5iZiI6MTUyNjA1ODU3MSwic2Vzc2lvbl9pZCI6ImRlNWIzNmE2YzQ3ODQ4YTNiYWZhYmRjZjY4OGFlYzAwIiwidmVyc2lvbiI6IjEuMC4wLjAiLCJzdWIiOiI2NTc4NjIiLCJpZCI6IjY1Nzg2MiIsInVzZXJuYW1lIjoic2hhc2hpZCIsIm5hbWUiOiJzaGFzaGlkIiwiZ2l2ZW5fbmFtZSI6InNoYXNoaSIsImZhbWlseV9uYW1lIjoidGhpcHBhcnRoeSIsImVtYWlsIjoic2hhc2hpX3RoaXBwYXJ0aHlAZ2FsbHVwLmNvbSIsImNvdW50cnkiOiJVU0EiLCJtZW1iZXJfaWQiOiI2NTY5MjEiLCJjbGllbnRfaWQiOiJHYWxsdXAuSWRlbnRpdHlTZXJ2ZXIiLCJzY29wZSI6WyJnYWxsdXBfY2xpZW50X2NvbnRleHQiLCJvZmZsaW5lX2FjY2VzcyIsInByaXZpbGVnZXMiLCJwcm9maWxlX2V4dGVuZGVkIiwicm9sZXMiLCJ0ZWFtIiwib3BlbmlkIiwicHJvZmlsZSIsImVtYWlsIl0sImF1dGhfdGltZSI6MTUyNjA1ODU3MCwiaWRwIjoiaWRzcnYiLCJwcml2aWxlZ2UiOlsiZGV2ZWxvcGVyIiwiZ2FsbHVwX2Fzc29jaWF0ZSIsInExMl9yZXBvcnRzIiwiYWN0aW9uX2xlYXJuX3VzZXIiLCJhcGlfZGVsZXRlX3dpZGdldF9kZXBlbmRlbmN5IiwiZXhwb3J0X3N1cnZleV9yZXNwb25kZW50cyIsImxtc191c2VyIiwiY3JlYXRlX3BvcnRhbF9jb21wb25lbnRzIiwicmVhZF9wb3J0YWxfY29tcG9uZW50cyIsImVkaXRfcG9ydGFsX2NvbXBvbmVudHMiLCJkZWxldGVfcG9ydGFsX2NvbXBvbmVudHMiLCJwb3J0YWxfYWRtaW5pc3RyYXRpb24iLCJ1c2VyX3Byb3h5X2FjY2VzcyIsIndvcmtwbGFjZV9yYXdfZGF0YV9leHBvcnRzIl0sInJvbGUiOlsiZGV2ZWxvcGVyIiwiZ2FsbHVwX2Fzc29jaWF0ZSIsImNsaWVudF91c2VyX2FkbWluaXN0cmF0b3IiLCJzZl90b3BfNSIsImdjcF9kZXZlbG9wZXIiLCJ3b3JrcGxhY2VfcmF3X2RhdGFfZXhwb3J0cyIsImFjY2Vzc19jb2RlX2FkbWluaXN0cmF0b3IiLCJhY2Nlc3NfY29kZV9kaXN0cmlidXRvciJdLCJhbXIiOlsicGFzc3dvcmQiXX0.iarzo92v-2t0KyDR_d7sZPkjF-sTOT5sOF0Vmse_oL16PhEAniSyESRQNiHa6rTztfclZBXoIb2rGZnez-iKGvq3YQk17uRebOl98g77VUotRmDiP181qaQCVxvu-zaObMSkBF1l5zl3r8swguDLg9euJcnsijeWeuObls-kP_jXvRpjTzhTOf4ju0Y-HnNoW4cxUy6CbPs7MlB8reYgcmsPputTe3jYI39z1U7NIDNgvwmPvFnrFell6fnpqyPf3ljutb_1xUJX-F0tiOg4BjwKAJO0104LGuhCDtEo1u3nKMaCA7tuwssCkRMrOLeZvCfupm2r0bFDFMs4Vx2zDg'
            } :
            {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            }
    };

    export interface IGetRequest {
        url: string,
        params: any
    }
    export interface IGetAllRequest {
        getRequests: IGetRequest[]
    }


    export function get<T>(url: string, params: any) {
        let apiUrl = baseUrl() + url;

        params = params || {};
        params = normalizeRequest(params);

        if (params != null) {
            Object
                .keys(params)
                .forEach((key, i) => {
                    i == 0
                        ? (apiUrl = apiUrl + "?" + key + "=" + params[key])
                        : (apiUrl = apiUrl + "&" + key + "=" + params[key])
                });
        }


        return new Promise<T>((resolve, reject) => {
            axios
                .get(apiUrl, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                })
                .catch((err) => {
                    reject(err);
                });
        });


    }


    export function getAll<T>(getAllRequest: IGetRequest[]) {

        let formattedRequests = [];
        getAllRequest.forEach((getRequest) => {
            let apiUrl = baseUrl() + getRequest.url;
            let params = getRequest.params || {};
            params = normalizeRequest(params);
            if (params != null) {
                Object
                    .keys(params)
                    .forEach((key, i) => {
                        i == 0
                            ? (apiUrl = apiUrl + "?" + key + "=" + params[key])
                            : (apiUrl = apiUrl + "&" + key + "=" + params[key])
                    });
            }

            formattedRequests.push(axios.get(apiUrl, config));
        }

        );

        let myObject = [];

        let responseData = [];
        let allGets = [];
        return new Promise<T[]>((resolve, reject) => {

            axios.all(formattedRequests)
                .then(axios.spread((...args) => {
                    for (let i = 0; i < args.length; i++) {

                        responseData.push(args[i].data);

                    }
                    resolve(responseData);
                }

                ))
                .catch((err) => {
                    reject(err);
                });
        });


    }

    //###### posts 

    class RequestHandler {

        static RejectionHandler(rejectionFunc: (error?: any) => void, error: AxiosError) {

            if (error.message === "Network Error") {
                window.location.reload();
            }

            if (!!error.response) {
                if (error.response.status === 401 || error.response.status === 405 || error.response.status == 403) {
                    window.location.reload();
                }
            }

            if (!!error.response) {
                if (!!error.response.data) {
                    rejectionFunc(error.response.data);
                } else {
                    rejectionFunc('undefined error');
                }
            }


        }

        static RejectionNoReLoadHandler(rejectionFunc: (error?: any) => void, error: AxiosError) {


            if (!!error.response) {
                if (!!error.response.data) {
                    rejectionFunc(error.response.data);
                } else {
                    rejectionFunc('undefined error');
                }
            }


        }
    }

    export function Post<T>(url: string, postParams: any): Promise<T> {
        postParams = postParams || {};
        postParams = normalizeRequest(postParams);
        return new Promise<T>((resolve, reject) => {
            axios.post(baseUrl() + url, postParams, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                }).catch((err) => {
                    reject(err);
                });
        });
    }

    export function PostWithHandleRejection<T>(url: string, postParams: any): Promise<T> {
        postParams = postParams || {};
        postParams = normalizeRequest(postParams);
        return new Promise<T>((resolve, reject) => {
            axios.post(baseUrl() + url, postParams, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                }).catch((err) => {
                    RequestHandler.RejectionHandler(reject, err);
                });
        });
    }

    export function PostWithRejectionNoReLoad<T>(url: string, postParams: any): Promise<T> {
        postParams = postParams || {};
        postParams = normalizeRequest(postParams);
        return new Promise<T>((resolve, reject) => {
            axios.post(baseUrl() + url, postParams, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                }).catch((err) => {
                    RequestHandler.RejectionNoReLoadHandler(reject, err);
                });
        });
    }
    export function DownloadPost(url: string, params: any) {

        params = normalizeRequest(params);

        axios.post(baseUrl() + url, params, { responseType: 'arraybuffer' })
            .then((response: any) => {
                DownloadHandlerExcel(response.data, 'Codes.xlsx');
                return Promise.resolve(true);
            });


    };



    const DownloadHandlerExcel = (data, filename, mime?) => {
        var blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;' });
        if (typeof window.navigator.msSaveBlob !== 'undefined') {
            // IE workaround for "HTML7007: One or more blob URLs were 
            // revoked by closing the blob for which they were created. 
            // These URLs will no longer resolve as the data backing 
            // the URL has been freed."
            window.navigator.msSaveBlob(blob, filename);
        }
        else {
            var blobURL = window.URL.createObjectURL(blob);
            let tempLink: any = document.createElement('a');
            tempLink.style = "display: none";
            tempLink.href = blobURL;
            tempLink.setAttribute('download', filename);
            tempLink.setAttribute('target', '_blank');
            document.body.appendChild(tempLink);
            tempLink.click();
            document.body.removeChild(tempLink);
            window.URL.revokeObjectURL(blobURL);
        }
    }


    export function Put<T>(url: string, putParams: any): Promise<T> {
        putParams = putParams || {};
        putParams = normalizeRequest(putParams);
        return new Promise<T>((resolve, reject) => {

            axios.put(baseUrl() + url, putParams, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                }).catch((err) => {
                    reject(err);
                });
        });
    }

    export function Delete<T>(url: string, deleteParams: any): Promise<T> {
        deleteParams = deleteParams || {};
        deleteParams = normalizeRequest(deleteParams);

        var data = deleteParams;
        return new Promise<T>((resolve, reject) => {
            axios.put(baseUrl() + url, data = deleteParams, config)
                .then((response: AxiosResponse) => {
                    resolve(response.data);
                }).catch((err) => {
                    reject(err);
                });
        });


    }
}
